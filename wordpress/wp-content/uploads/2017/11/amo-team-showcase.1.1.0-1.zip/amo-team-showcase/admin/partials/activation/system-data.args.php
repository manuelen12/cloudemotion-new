<?php
/**
 * Data/values to save system options for the plugin in the database. On plugin activation / update.
 *
 * @since   1.0.0
 */
return array(
	'version'           => AMO_TEAM_SHOWCASE_VERSION,
	'notice-wp-version' => true,
	'notice-thumb'      => true,
);
